import * as React from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';

export function TimeDisplay() {
  const [currentTime, setCurrentTime] = React.useState(new Date());

  React.useEffect(() => {
    const timer = setInterval(() => {
      setCurrentTime(new Date());
    }, 1000);

    return () => clearInterval(timer);
  }, []);

  const formatTime = (date: Date) => {
    return date.toLocaleTimeString();
  };

  const formatDate = (date: Date) => {
    return date.toLocaleDateString();
  };

  return (
    <Card className="w-full max-w-md">
      <CardHeader>
        <CardTitle>Current Time</CardTitle>
      </CardHeader>
      <CardContent>
        <div className="text-center">
          <div className="text-3xl font-mono font-bold mb-2">
            {formatTime(currentTime)}
          </div>
          <div className="text-lg text-muted-foreground">
            {formatDate(currentTime)}
          </div>
        </div>
      </CardContent>
    </Card>
  );
}