import * as React from 'react';
import { Button } from '@/components/ui/button';
import { TimeDisplay } from '@/components/TimeDisplay';

function App() {
  return (
    <div className="min-h-screen">
      <div className="container mx-auto px-4 py-8">
        <h1 className="text-4xl font-bold mb-8">Instance starter</h1>
        <TimeDisplay />
      </div>
    </div>
  );
}

export default App;